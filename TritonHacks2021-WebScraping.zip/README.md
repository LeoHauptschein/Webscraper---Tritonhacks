# TritonHacks-WebScraping
The python web scraping starter kit for TritonHacks2021
